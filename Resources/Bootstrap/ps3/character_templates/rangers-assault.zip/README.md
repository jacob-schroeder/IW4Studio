Rivet Robot • Rangers Assault 1 Blender kit

The two rangers_*_rig.blend files are empty stock-compatible body and viewhands
rigs. The Rivet files contain original simple robot geometry on those exact
rigs. The body includes its own head; the first-person hands are separate.

Do not rename, delete, reparent, or reorder bones, including tag_* bones.
Do not change their rest pose. Each bone retains its native iw4_index.
One Blender unit equals one IW4 map unit; +X is forward and Z is up.

Edit rivet_body.blend and rivet_viewhands.blend separately. Export each as GLB
with the armature and meshes selected, Skinning on, Deformation Bones Only off,
Export Rest Position on, animation off, and Y Up on. Keep the four materials
as solid colors. No texture or normal map is needed by this example.

In IW4Radiant, choose Create > Factions > Rangers > Assault 1 > Replace
appearance > Import Blender model. Select rivet_body.glb, then
rivet_viewhands.glb. Preview body and View hands, then Apply and save the map.
The importer preserves the stock skeleton and generates game LODs. Final native
import/LOD validation and in-game verification have not been performed here.

Authored mesh counts before GLB expansion: body 1164 triangles, 3492 triangle corners; viewhands 736 triangles, 2208 triangle corners. These are source construction counts, not measured native PS3 stream counts.

Rigid articulation: each metal segment follows one bone with full weight. Upper arms follow shoulders, forearms follow elbows, thighs follow hips, and shins follow knees. Hands and fingers retain their individual joint articulation. The stock skeleton, rest pose, geometry and materials are unchanged.

To update an existing map, reimport BOTH rivet_body.glb and rivet_viewhands.glb using the updated IW4Radiant tools, Apply, save, and build a new fastfile. This asset revision has not yet been verified in-game.
